print("Python is fun!")
